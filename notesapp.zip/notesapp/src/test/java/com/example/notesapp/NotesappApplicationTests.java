package com.example.notesapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotesappApplicationTests {

	@Test
	void contextLoads() {
	}

}
